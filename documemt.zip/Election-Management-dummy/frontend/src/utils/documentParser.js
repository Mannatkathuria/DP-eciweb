const normaliseText = (text = "") => String(text).replace(/\r/g, "").replace(/[|]/g, "I");

const cleanValue = value => String(value || "")
  .replace(/^[\s:;#-]+|[\s:;#-]+$/g, "")
  .replace(/\s{2,}/g, " ")
  .trim();

const patterns = {
  aadhaar: /(?:\b\d{4}[ -]?\d{4}[ -]?\d{4}\b|\bX{4}[ -]?X{4}[ -]?\d{4}\b)/i,
  pan: /\b[A-Z]{5}\d{4}[A-Z]\b/i,
  voter_id: /\b[A-Z]{2,4}\s?\d{5,10}\b/i,
  passport: /\b[A-Z][0-9]{7}\b/i,
  driving_licence: /\b[A-Z]{2}\s?\d{2}\s?\d{4}\s?\d{7,}\b/i
};

export function detectDocumentType(text = "") {
  const t = normaliseText(text).toUpperCase();
  if (/PERMANENT ACCOUNT NUMBER|INCOME TAX DEPARTMENT|\bPAN\b/.test(t) && patterns.pan.test(t)) return "pan";
  if (/ELECTION COMMISSION|ELECTOR PHOTO ID|ELECTORAL PHOTO ID|\bEPIC\b/.test(t) || patterns.voter_id.test(t)) return "voter_id";
  if (/PASSPORT|REPUBLIC OF INDIA|PERSONAL NO\./.test(t) && patterns.passport.test(t)) return "passport";
  if (/DRIVING LICEN[CS]E|TRANSPORT DEPARTMENT|MOTOR VEHICLE/.test(t) && patterns.driving_licence.test(t)) return "driving_licence";
  if (/AADHAAR|UIDAI|UNIQUE IDENTIFICATION AUTHORITY|GOVERNMENT OF INDIA/.test(t) && patterns.aadhaar.test(t)) return "aadhaar";
  return "other";
}

function findLabeledValue(lines, labels) {
  const labelRegex = new RegExp(`(?:${labels})\\s*[:：-]?\\s*(.{2,80})`, "i");
  for (const line of lines) {
    const match = line.match(labelRegex);
    if (match) {
      const value = cleanValue(match[1].split(/\s{3,}|\b(?:DOB|DATE OF BIRTH|GENDER|SEX|ADDRESS|VALIDITY)\b/i)[0]);
      if (value && !/^(india|government|male|female|m|f)$/i.test(value)) return value;
    }
  }
  return "";
}

function parseDate(text) {
  const dobLine = String(text).split("\n").find(line => /\b(?:DOB|DATE OF BIRTH|BIRTH DATE)\b/i.test(line));
  const source = dobLine || text;
  const match = source.match(/\b(0?[1-9]|[12]\d|3[01])[-/.](0?[1-9]|1[0-2])[-/.]((?:19|20)\d{2})\b/);
  if (!match) return "";
  return `${match[3]}-${String(match[2]).padStart(2, "0")}-${String(match[1]).padStart(2, "0")}`;
}

function extractDocumentNumber(text, type) {
  const t = normaliseText(text).toUpperCase();
  if (type === "aadhaar") {
    const labeled = findLabeledValue(t.split("\n"), "(?:AADHAAR(?:\s+(?:NO|NUMBER))?|UID) ");
    const match = labeled.match(patterns.aadhaar) || t.match(patterns.aadhaar);
    return match ? match[0].replace(/[ -]/g, "") : "";
  }
  if (type === "pan") return t.match(patterns.pan)?.[0] || "";
  if (type === "voter_id") return t.match(patterns.voter_id)?.[0].replace(/\s/g, "") || "";
  if (type === "passport") return t.match(patterns.passport)?.[0] || "";
  if (type === "driving_licence") {
    return findLabeledValue(t.split("\n"), "(?:DL|DRIVING LICEN[CS]E)(?:\s*(?:NO|NUMBER))?")
      || t.match(patterns.driving_licence)?.[0].replace(/\s/g, "") || "";
  }
  return "";
}

export function parseDocument(text, selectedType = "auto") {
  const cleaned = normaliseText(text);
  const lines = cleaned.split("\n").map(cleanValue).filter(Boolean);
  const documentType = selectedType === "auto" ? detectDocumentType(cleaned) : selectedType;
  const dateOfBirth = parseDate(cleaned);
  const labeledName = findLabeledValue(lines, "(?:NAME|HOLDER'?S NAME|SURNAME|GIVEN NAME)");
  const name = labeledName || lines.find(line =>
    /^[A-Z][A-Z .'-]{3,}$/.test(line.toUpperCase()) &&
    !/^(NAME|SURNAME|GIVEN NAME|DOB|DATE OF BIRTH|BIRTH DATE|FATHER.?S NAME|MOTHER.?S NAME|HOLDER.?S NAME|IDENTIFICATION NO|ID NO|PAN|EPIC)$/i.test(line) &&
    !/(GOVERNMENT|INDIA|AADHAAR|UIDAI|PASSPORT|ELECTION|COMMISSION|IDENTITY|INCOME TAX|DRIVING LICEN[CS]E|DATE OF BIRTH|PERMANENT ACCOUNT|SIGNATURE|ADDRESS|MALE|FEMALE)/i.test(line) &&
    !/\d/.test(line)
  ) || "";

  const documentNumber = extractDocumentNumber(cleaned, documentType);
  const epic = documentType === "voter_id" ? documentNumber : "";

  return {
    documentType,
    documentNumber,
    epic,
    name: cleanValue(name).replace(/\s{2,}/g, " "),
    dateOfBirth,
    extractionMethod: "tesseract-ocr",
    extractionStatus: documentNumber && name ? "fields_extracted" : "partial"
  };
}
