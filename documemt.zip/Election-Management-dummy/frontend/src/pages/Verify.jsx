import { useEffect, useRef, useState } from "react";
import "./Verify.css";
import api from "../api/axios";

function OutcomeCard({ result, onReset }) {
    const ok = result.status === "verified";

    return (
        <section className="verify-card">
            <p className="step-label">RESULT</p>

            <div className={ok ? "success-box" : "record-warning"}>
                <strong>
                    {ok ? "Verification Successful" : "Manual / BLO Review Required"}
                </strong>

                {ok ? (
                    <p>
                        Your record, identity information, face and liveness
                        checks are consistent. Your details will be available to
                        the polling official as a pre-verification result.
                    </p>
                ) : (
                    <>
                        <p>
                            This does <b>not</b> affect your right to vote. A
                            Booth Level Officer will review your case; you can
                            also complete the normal verification at the polling
                            station.
                        </p>
                        <ul>
                            {(result.reasons || []).map((r) => (
                                <li key={r}>{r}</li>
                            ))}
                        </ul>
                    </>
                )}

                {result.notes?.length > 0 && (
                    <p><em>{result.notes.join(" ")}</em></p>
                )}
            </div>

            <div className="record-warning">
                <strong>Prototype notice</strong>
                <p>
                    Automated results only assist election officials. They are not
                    used independently to determine eligibility or identity.
                </p>
            </div>

            <button type="button" className="verify-button" onClick={onReset}>
                Start New Verification
            </button>
        </section>
    );
}

function Verify() {
    const [step, setStep] = useState(1);
    const [method, setMethod] = useState("epic");

    const [formData, setFormData] = useState({
        epic: "",
        name: "",
        state: "",
        district: "",
        constituency: "",
        mobile: ""
    });

    const [elector, setElector] = useState(null);
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);
    const [identityMethod, setIdentityMethod] = useState(null);
    const [cameraStream, setCameraStream] = useState(null);
    const [faceResult, setFaceResult] = useState(null);
    const [faceLoading, setFaceLoading] = useState(false);
    const [verificationId, setVerificationId] = useState(null);
    const [identityResult, setIdentityResult] = useState(null);
    const [challenge, setChallenge] = useState(null);
    const [prompt, setPrompt] = useState("");

    const videoRef = useRef(null);

    // Attach the stream once the <video> element exists, and always release the camera.
    useEffect(() => {
        if (videoRef.current && cameraStream) {
            videoRef.current.srcObject = cameraStream;
        }
    }, [cameraStream]);

    useEffect(() => {
        return () => {
            cameraStream?.getTracks().forEach((t) => t.stop());
        };
    }, [cameraStream]);

    const handleChange = (e) => {
        const { name, value } = e.target;

        setFormData((prev) => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSearch = async (e) => {
        e.preventDefault();

        setError("");

        if (method === "epic" && !formData.epic.trim()) {
            setError("Please enter your EPIC number.");
            return;
        }

        if (method === "details") {
            if (!formData.name.trim() || !formData.state) {
                setError("Please enter the required personal details.");
                return;
            }
        }

        if (method === "mobile" && !formData.mobile.trim()) {
            setError("Please enter your registered mobile number.");
            return;
        }

        try {
            setLoading(true);

            const response = await api.post("/electors/search", {
                method,
                epic: formData.epic,
                name: formData.name,
                state: formData.state,
                district: formData.district,
                assemblyConstituency: formData.constituency,
                mobile: formData.mobile
            });

            console.log("Elector response:", response.data);

            setElector(response.data.data);
            setStep(2);

        } catch (error) {
            console.error("Elector search failed:", error);

            setError(
                error.response?.data?.message ||
                "Unable to search the electoral record."
            );

        } finally {
            setLoading(false);
        }
    };

    const confirmRecord = () => {
        if (!elector) {
            setError("No electoral record is available for confirmation.");
            return;
        }

        setError("");
        setStep(3);
    };

    const handleIdentityVerification = async (method) => {

        if (!elector) {
            setError("Electoral record is missing.");
            return;
        }

        setError("");
        setIdentityMethod(method);
        setLoading(true);

        try {
            const response = await api.post("/verification/identity", {
                electorId: elector.epic,
                method
            });

            const data = response.data.data;

            setVerificationId(data.verificationId);
            setIdentityResult(data.identity);

            if (data.status === "review_required") {
                // Never an automatic rejection - routed to the BLO.
                setFaceResult(data);
            }

            setStep(4);

        } catch (error) {
            console.error("Identity verification failed:", error);

            setError(
                error.response?.data?.message ||
                "Identity verification could not be completed."
            );

        } finally {
            setLoading(false);
        }
    };

    const resetAll = () => {
        stopCamera();
        setStep(1);
        setElector(null);
        setIdentityMethod(null);
        setIdentityResult(null);
        setVerificationId(null);
        setChallenge(null);
        setFaceResult(null);
        setError("");
    };

    const goBack = () => {
        setError("");
        setStep((prev) => Math.max(1, prev - 1));
    };

    const startCamera = async () => {
        try {
            setError("");

            const stream = await navigator.mediaDevices.getUserMedia({
                video: true,
                audio: false
            });

            setCameraStream(stream);

            if (videoRef.current) {
                videoRef.current.srcObject = stream;
            }

        } catch (error) {
            console.error("Camera error:", error);

            setError(
                "Unable to access the camera. Please allow camera permission."
            );
        }
    };

    const stopCamera = () => {
        if (cameraStream) {
            cameraStream.getTracks().forEach((track) => track.stop());
        }

        setCameraStream(null);
    };

    const CHALLENGE_TEXT = {
        blink: "Blink your eyes naturally a couple of times",
        left: "Slowly turn your head to YOUR left, then look back",
        right: "Slowly turn your head to YOUR right, then look back"
    };

    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

    /* Captures ~3.5 seconds of frames (about 10 fps) as small JPEGs. */
    const captureFrames = async () => {
        const video = videoRef.current;
        const scale = Math.min(1, 480 / video.videoWidth);
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(video.videoWidth * scale);
        canvas.height = Math.round(video.videoHeight * scale);
        const ctx = canvas.getContext("2d");

        const frames = [];
        const end = Date.now() + 3500;

        while (Date.now() < end && frames.length < 36) {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            frames.push(canvas.toDataURL("image/jpeg", 0.6));
            await sleep(100);
        }
        return frames;
    };

    const runFaceVerification = async () => {
        if (!videoRef.current || !videoRef.current.videoWidth) {
            setError("Camera is not ready yet. Please wait a moment and try again.");
            return;
        }

        try {
            setFaceLoading(true);
            setError("");
            setFaceResult(null);

            // 1. Server picks a random challenge (cannot be chosen by the client).
            let currentChallenge = challenge;
            if (!currentChallenge) {
                const c = await api.post(`/verification/${verificationId}/challenge`);
                currentChallenge = c.data.data.challenge;
                setChallenge(currentChallenge);
            }

            // 2. Show it, give the person a moment, then record.
            setPrompt(CHALLENGE_TEXT[currentChallenge]);
            await sleep(1500);
            setPrompt("Recording… " + CHALLENGE_TEXT[currentChallenge]);
            const frames = await captureFrames();
            setPrompt("Processing…");

            // 3. Send frames for detection, matching and liveness.
            const response = await api.post(
                `/verification/${verificationId}/face`,
                { frames }
            );

            const data = response.data.data;

            if (data.status === "retry") {
                setChallenge(data.challenge);
                setError(
                    `${data.reasons.join(" ")} Please try again (${data.attemptsLeft} attempt left) – new instruction below.`
                );
            } else {
                setFaceResult(data);
                stopCamera();
            }

        } catch (error) {
            console.error("Face verification failed:", error);

            setError(
                error.response?.data?.message ||
                "Face verification service unavailable."
            );

        } finally {
            setPrompt("");
            setFaceLoading(false);
        }
    };

    return (
        <main className="verify-page">

            <div className="verify-container">

                <header className="verify-header">

                    <p className="eyebrow">
                        PRE-ELECTION VERIFICATION
                    </p>

                    <h1>
                        Verify your electoral record
                    </h1>

                    <p>
                        Confirm your electoral record before proceeding
                        to identity verification.
                    </p>

                </header>

                <div className="progress">

                    <div
                        className={`progress-step ${
                            step >= 1 ? "active" : ""
                        }`}
                    >
                        <span>1</span>
                        <p>Electoral Record</p>
                    </div>

                    <div className="progress-line" />

                    <div
                        className={`progress-step ${
                            step >= 2 ? "active" : ""
                        }`}
                    >
                        <span>2</span>
                        <p>Confirm</p>
                    </div>

                    <div className="progress-line" />

                    <div
                        className={`progress-step ${
                            step >= 3 ? "active" : ""
                        }`}
                    >
                        <span>3</span>
                        <p>Identity</p>
                    </div>

                    <div className="progress-line" />

                    <div
                        className={`progress-step ${
                            step >= 4 ? "active" : ""
                        }`}
                    >
                        <span>4</span>
                        <p>Face & Liveness</p>
                    </div>

                </div>

                {/* STEP 1 */}

                {step === 1 && (
                    <section className="verify-card">

                        <h2>
                            Find your electoral record
                        </h2>

                        <p className="card-description">
                            Select an available method to locate your
                            electoral record.
                        </p>

                        <div className="method-tabs">

                            <button
                                type="button"
                                className={method === "epic" ? "active" : ""}
                                onClick={() => {
                                    setMethod("epic");
                                    setError("");
                                }}
                            >
                                EPIC Number
                            </button>

                            <button
                                type="button"
                                className={method === "details" ? "active" : ""}
                                onClick={() => {
                                    setMethod("details");
                                    setError("");
                                }}
                            >
                                Personal Details
                            </button>

                            <button
                                type="button"
                                className={method === "mobile" ? "active" : ""}
                                onClick={() => {
                                    setMethod("mobile");
                                    setError("");
                                }}
                            >
                                Mobile Number
                            </button>

                        </div>

                        {error && (
                            <div
                                className="verification-error"
                                role="alert"
                            >
                                {error}
                            </div>
                        )}

                        <form onSubmit={handleSearch}>

                            {method === "epic" && (
                                <div className="form-group">

                                    <label htmlFor="epic">
                                        EPIC Number
                                    </label>

                                    <input
                                        id="epic"
                                        name="epic"
                                        type="text"
                                        value={formData.epic}
                                        onChange={(e) =>
                                            setFormData((prev) => ({
                                                ...prev,
                                                epic: e.target.value.toUpperCase()
                                            }))
                                        }
                                        placeholder="Enter your EPIC number"
                                        autoComplete="off"
                                    />

                                    <span>
                                        Enter the EPIC number printed on
                                        your Elector Photo Identity Card.
                                    </span>

                                </div>
                            )}

                            {method === "details" && (
                                <div className="form-section">

                                    <div className="form-group">

                                        <label htmlFor="name">
                                            Name
                                        </label>

                                        <input
                                            id="name"
                                            name="name"
                                            type="text"
                                            value={formData.name}
                                            onChange={handleChange}
                                            placeholder="Enter name"
                                        />

                                    </div>

                                    <div className="form-row">

                                        <div className="form-group">

                                            <label htmlFor="state">
                                                State / UT
                                            </label>

                                            <select
                                                id="state"
                                                name="state"
                                                value={formData.state}
                                                onChange={handleChange}
                                            >
                                                <option value="">
                                                    Select State / UT
                                                </option>

                                                <option value="Punjab">
                                                    Punjab
                                                </option>

                                                <option value="Himachal Pradesh">
                                                    Himachal Pradesh
                                                </option>

                                                <option value="Haryana">
                                                    Haryana
                                                </option>

                                                <option value="Delhi">
                                                    Delhi
                                                </option>

                                            </select>

                                        </div>

                                        <div className="form-group">

                                            <label htmlFor="district">
                                                District
                                            </label>

                                            <input
                                                id="district"
                                                name="district"
                                                type="text"
                                                value={formData.district}
                                                onChange={handleChange}
                                                placeholder="Enter district"
                                            />

                                        </div>

                                    </div>

                                    <div className="form-group">

                                        <label htmlFor="constituency">
                                            Assembly Constituency
                                        </label>

                                        <input
                                            id="constituency"
                                            name="constituency"
                                            type="text"
                                            value={formData.constituency}
                                            onChange={handleChange}
                                            placeholder="Enter constituency"
                                        />

                                    </div>

                                </div>
                            )}

                            {method === "mobile" && (
                                <div className="form-group">

                                    <label htmlFor="mobile">
                                        Registered Mobile Number
                                    </label>

                                    <input
                                        id="mobile"
                                        name="mobile"
                                        type="tel"
                                        value={formData.mobile}
                                        onChange={handleChange}
                                        placeholder="Enter registered mobile number"
                                        autoComplete="tel"
                                    />

                                    <span>
                                        This method will be available only
                                        where supported by the authorised
                                        electoral service.
                                    </span>

                                </div>
                            )}

                            <button
                                type="submit"
                                className="verify-button"
                                disabled={loading}
                                onClick={() => console.log("Clicked")}
                            >
                                {loading ? "Searching..." : "Continue"}
                            </button>

                        </form>

                    </section>
                )}

                {/* STEP 2 */}

                {step === 2 && elector && (
                    <section className="verify-card">

                        <div className="step-heading">

                            <div>
                                <p className="step-label">
                                    STEP 2
                                </p>

                                <h2>
                                    Confirm electoral record
                                </h2>
                            </div>

                            <span className="record-status">
                                Record Located
                            </span>

                        </div>

                        <p className="card-description">
                            Review the electoral information before
                            continuing to identity verification.
                        </p>

                        <div className="record-box">

                            <div className="record-row">
                                <span>Name</span>
                                <strong>{elector.name || "—"}</strong>
                            </div>

                            <div className="record-row">
                                <span>EPIC Number</span>
                                <strong>{elector.epic || "—"}</strong>
                            </div>

                            <div className="record-row">
                                <span>State</span>
                                <strong>{elector.state || "—"}</strong>
                            </div>

                            <div className="record-row">
                                <span>District</span>
                                <strong>{elector.district || "—"}</strong>
                            </div>

                            <div className="record-row">
                                <span>Assembly Constituency</span>
                                <strong>
                                    {elector.assemblyConstituency || "—"}
                                </strong>
                            </div>

                            <div className="record-row">
                                <span>Part Number</span>
                                <strong>{elector.partNumber || "—"}</strong>
                            </div>

                            <div className="record-row">
                                <span>Polling Station</span>
                                <strong>
                                    {elector.pollingStation || "—"}
                                </strong>
                            </div>

                        </div>

                        <div className="record-warning">

                            <strong>
                                Important
                            </strong>

                            <p>
                                Please ensure that the displayed
                                electoral information belongs to you
                                before proceeding.
                            </p>

                        </div>

                        {error && (
                            <div
                                className="verification-error"
                                role="alert"
                            >
                                {error}
                            </div>
                        )}

                        <div className="step-actions">

                            <button
                                type="button"
                                className="back-button"
                                onClick={goBack}
                            >
                                Back
                            </button>

                            <button
                                type="button"
                                className="verify-button"
                                onClick={confirmRecord}
                            >
                                Confirm & Continue
                            </button>

                        </div>

                    </section>
                )}

                {/* STEP 3 */}

                {step === 3 && (
                    <section className="verify-card">

                        <p className="step-label">
                            STEP 3
                        </p>

                        <h2>
                            Verify your identity
                        </h2>

                        <p className="card-description">
                            Select an identity document to continue verification.
                            The selected document will be checked against your
                            electoral record.
                        </p>

                        {error && (
                            <div
                                className="verification-error"
                                role="alert"
                            >
                                {error}
                            </div>
                        )}

                        <div className="identity-options">

                            <button
                                type="button"
                                className="identity-option"
                                onClick={() => handleIdentityVerification("aadhaar")}
                            >
                                <strong>Aadhaar</strong>

                                <span>
                                    Verify using an authorised Aadhaar verification
                                    service.
                                </span>
                            </button>

                            <button
                                type="button"
                                className="identity-option"
                                onClick={() => handleIdentityVerification("digilocker")}
                            >
                                <strong>DigiLocker</strong>

                                <span>
                                    Verify using an issued government document.
                                </span>
                            </button>

                            <button
                                type="button"
                                className="identity-option"
                                onClick={() => handleIdentityVerification("pan")}
                            >
                                <strong>PAN</strong>

                                <span>
                                    Verify identity using an authorised PAN
                                    verification service.
                                </span>
                            </button>

                            <button
                                type="button"
                                className="identity-option"
                                onClick={() => handleIdentityVerification("dl")}
                            >
                                <strong>Driving Licence</strong>

                                <span>
                                    Verify using an authorised transport
                                    department service.
                                </span>
                            </button>

                        </div>

                        {loading && (
                            <div className="verification-loading">
                                Verifying identity...
                            </div>
                        )}

                        <div className="step-actions">

                            <button
                                type="button"
                                className="back-button"
                                onClick={goBack}
                                disabled={loading}
                            >
                                Back
                            </button>

                        </div>

                    </section>
                )}

                {/* STEP 4 */}

                {step === 4 && faceResult && (
                    <OutcomeCard result={faceResult} onReset={resetAll} />
                )}

                {step === 4 && !faceResult && (
                    <section className="verify-card">

                        <p className="step-label">
                            STEP 4
                        </p>

                        <h2>
                            Face & Liveness Verification
                        </h2>

                    <p className="card-description">
                        Complete a short face verification to confirm that
                        you are the person associated with the verified
                        electoral record.
                    </p>

                    <div className="liveness-box">

                        <div className="liveness-icon">
                            ✓
                        </div>

                        <h3>
                            Ready for verification
                        </h3>

                        <p>
                            {identityResult?.status === "minor_discrepancy"
                                ? "Your identity document was matched with a minor discrepancy, which has been recorded."
                                : "Your identity document is consistent with your electoral record."}
                        </p>

                        <p>
                            Next, a short camera check confirms that a live
                            person is present.
                        </p>

                    </div>

                    <div className="record-warning">

                        <strong>
                            Privacy notice
                        </strong>

                        <p>
                            Camera access should only be requested when the
                            authorised liveness verification process begins.
                            Do not upload or store biometric data unnecessarily.
                        </p>

                    </div>

                    <div className="step-actions">

                        <button
                            type="button"
                            className="back-button"
                            onClick={goBack}
                        >
                            Back
                        </button>

                        <button
                            type="button"
                            className="verify-button"
                            onClick={() => setStep(5)}
                            disabled={!!faceResult}
                        >
                            Start Face Verification
                        </button>

                    </div>

                </section>
                )}

                {/* STEP 5 */}

                {step === 5 && (
                    <section className="verify-card">

                        <p className="step-label">
                            STEP 5
                        </p>

                        <h2>
                            Face & Liveness Check
                        </h2>

                        <p className="card-description">
                            Use your camera for the biometric demonstration.
                            Follow the instructions displayed by the verification system.
                        </p>

                        {error && (
                            <div
                                className="verification-error"
                                role="alert"
                            >
                                {error}
                            </div>
                        )}

                        {!cameraStream && !faceResult && (
                            <div className="face-start">

                                <div className="record-warning">

                                    <strong>
                                        Before you continue
                                    </strong>

                                    <p>
                                        Make sure your face is clearly visible,
                                        your camera is enabled, and you are in a
                                        well-lit environment.
                                    </p>

                                </div>

                                <button
                                    type="button"
                                    className="verify-button"
                                    onClick={startCamera}
                                >
                                    Enable Camera
                                </button>

                            </div>
                        )}

                        {cameraStream && !faceResult && (
                            <div className="face-verification">

                                <div className="camera-container">

                                    <video
                                        ref={videoRef}
                                        autoPlay
                                        playsInline
                                        muted
                                        className="camera-preview"
                                    />

                                </div>

                                <div className="record-warning">

                                    <strong>
                                        {prompt ? "Follow this instruction" : "Position yourself correctly"}
                                    </strong>

                                    <p>
                                        {prompt ||
                                            "Keep your face centered and clearly visible, then press Run Liveness Check."}
                                    </p>

                                </div>

                                <div className="step-actions">

                                    <button
                                        type="button"
                                        className="back-button"
                                        onClick={stopCamera}
                                        disabled={faceLoading}
                                    >
                                        Stop Camera
                                    </button>

                                    <button
                                        type="button"
                                        className="verify-button"
                                        onClick={runFaceVerification}
                                        disabled={faceLoading}
                                    >
                                        {faceLoading
                                            ? "Processing..."
                                            : "Run Liveness Check"}
                                    </button>

                                </div>

                            </div>
                        )}

                        {faceResult && (
                            <OutcomeCard result={faceResult} onReset={resetAll} />
                        )}

                    </section>
                )}

                <div className="progress">

                <div className={`progress-step ${step >= 1 ? "active" : ""}`}>
                    <span>1</span>
                    <p>Electoral Record</p>
                </div>

                <div className="progress-line" />

                <div className={`progress-step ${step >= 2 ? "active" : ""}`}>
                    <span>2</span>
                    <p>Confirm</p>
                </div>

                <div className="progress-line" />

                <div className={`progress-step ${step >= 3 ? "active" : ""}`}>
                    <span>3</span>
                    <p>Identity</p>
                </div>

                <div className="progress-line" />

                <div className={`progress-step ${step >= 4 ? "active" : ""}`}>
                    <span>4</span>
                    <p>Face & Liveness</p>
                </div>

                <div className="progress-line" />

                <div className={`progress-step ${step >= 5 ? "active" : ""}`}>
                    <span>5</span>
                    <p>Complete</p>
                </div>

            </div>

                <div className="verification-note">

                    <strong>
                        About this verification
                    </strong>

                    <p>
                        This system is intended to assist with pre-election
                        verification and identification of cases requiring
                        further review. It does not independently determine
                        an elector's eligibility to vote.
                    </p>

                </div>

            </div>

        </main>
    );
}

export default Verify;