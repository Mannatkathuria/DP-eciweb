import express from "express";
import {
    submitIdentity,
    issueChallenge,
    submitFace
} from "../controllers/verification.controller.js";

const router = express.Router();

router.post("/identity", submitIdentity);
router.post("/:id/challenge", issueChallenge);
router.post("/:id/face", submitFace);

export default router;
