import crypto from "crypto";
import { getElectorByEpic } from "../repositories/elector.repository.js";
import { getVerification, saveVerification } from "../repositories/verification.repository.js";
import { ApiError } from "../utils/ApiErrors.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { SUPPORTED_METHODS, fetchCredential, compareIdentity } from "../services/identity.service.js";
import { verifyFace } from "../services/faceClient.js";

const CHALLENGES = ["blink", "left", "right"];
const MAX_FACE_ATTEMPTS = 2;
const randomChallenge = (exclude) => {
    const pool = CHALLENGES.filter((c) => c !== exclude);
    return pool[crypto.randomInt(pool.length)];
};

const finish = (verification, status, reasons = []) => {
    verification.status = status;
    verification.reasons = reasons;
    verification.completedAt = new Date().toISOString();
    verification.durationMs =
        new Date(verification.completedAt).getTime() - new Date(verification.startedAt).getTime();
};

const getActiveVerification = async (id) => {
    const verification = await getVerification(id);
    if (!verification) throw new ApiError(404, "Verification session not found.");
    if (verification.status !== "in_progress") {
        throw new ApiError(409, "This verification session has already been completed.");
    }
    return verification;
};

export const submitIdentity = asyncHandler(async (req, res) => {
    const { electorId, method } = req.body ?? {};
    if (!electorId) throw new ApiError(400, "A valid electorId is required.");
    if (!SUPPORTED_METHODS.includes(method)) throw new ApiError(400, "Unsupported identity method.");

    const elector = await getElectorByEpic(electorId);
    if (!elector || !elector.isActive) throw new ApiError(404, "Electoral record not found.");

    let result;
    try {
        result = compareIdentity(elector, await fetchCredential(method, elector));
    } catch {
        result = { status: "unavailable", comparison: {}, reason: "Technical failure while retrieving the credential." };
    }

    const verification = {
        _id: crypto.randomUUID(), elector: elector._id, epic: elector.epic,
        identity: { method, status: result.status, comparison: result.comparison, checkedAt: new Date().toISOString() },
        face: { challenge: null, attempts: 0, match: null },
        status: "in_progress", reasons: [], notes: result.note ? [result.note] : [],
        startedAt: new Date().toISOString()
    };

    if (result.status === "significant_discrepancy" || result.status === "unavailable") {
        finish(verification, "review_required", [result.reason]);
    }

    await saveVerification(verification);
    res.json({ success: true, data: {
        verificationId: verification._id, status: verification.status,
        reasons: verification.reasons, identity: { method, status: result.status, note: result.note || null }
    }});
});

export const issueChallenge = asyncHandler(async (req, res) => {
    const verification = await getActiveVerification(req.params.id);
    verification.face.challenge = randomChallenge(verification.face.challenge);
    await saveVerification(verification);
    res.json({ success: true, data: { challenge: verification.face.challenge, attemptsUsed: verification.face.attempts } });
});

export const submitFace = asyncHandler(async (req, res) => {
    const verification = await getActiveVerification(req.params.id);
    const { frames } = req.body ?? {};

    if (!verification.face.challenge) throw new ApiError(400, "Request a liveness challenge first.");
    if (!Array.isArray(frames) || frames.length < 8 || frames.length > 40) {
        throw new ApiError(400, "Between 8 and 40 camera frames are required.");
    }
    if (frames.some((f) => typeof f !== "string" || !f.startsWith("data:image/") || f.length > 1_500_000)) {
        throw new ApiError(400, "Invalid frame data.");
    }

    verification.face.attempts += 1;
    verification.face.checkedAt = new Date().toISOString();

    let result;
    try {
        result = await verifyFace({ epic: verification.epic, frames, challenge: verification.face.challenge });
    } catch {
        finish(verification, "review_required", ["Technical failure: face verification service unavailable."]);
        await saveVerification(verification);
        return res.json({ success: true, data: { status: "review_required", reasons: verification.reasons, technicalFailure: true } });
    }

    verification.face.detected = !!result.faceDetected;
    verification.face.match = result.faceMatch ?? null;
    verification.face.distance = result.distance ?? null;
    verification.face.liveness = !!result.liveness;

    const reasons = [];
    if (!result.faceDetected) reasons.push("No single clear face was detected.");
    else if (result.faceMatch === null) reasons.push("No reference photograph is available for comparison.");
    else if (!result.faceMatch) reasons.push("Face verification did not match the reference photograph.");
    if (!result.liveness) reasons.push("Liveness challenge was not completed.");

    const retryable = reasons.length > 0 && result.faceMatch !== null;
    if (reasons.length === 0) finish(verification, "verified");
    else if (retryable && verification.face.attempts < MAX_FACE_ATTEMPTS) {
        verification.face.challenge = randomChallenge(verification.face.challenge);
        await saveVerification(verification);
        return res.json({ success: true, data: {
            status: "retry", reasons, challenge: verification.face.challenge,
            attemptsLeft: MAX_FACE_ATTEMPTS - verification.face.attempts
        }});
    } else finish(verification, "review_required", reasons);

    await saveVerification(verification);
    res.json({ success: true, data: {
        status: verification.status, reasons: verification.reasons, notes: verification.notes,
        face: { detected: verification.face.detected, match: verification.face.match,
            liveness: verification.face.liveness, challenge: verification.face.challenge }
    }});
});
